<?php if(! defined('ABSPATH')){ return; } ?>
<!-- Pagination -->
<div class="pagination--<?php echo esc_attr( $blog_style ); ?>">
    <?php zn_pagination(); ?>
</div>
